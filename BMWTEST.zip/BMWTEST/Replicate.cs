﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
using System.Threading.Tasks;

namespace BMWTEST
{
    public partial class Replicate : Form
    {
        public Replicate()
        {
            InitializeComponent();
        }

        

        public void LogFile(string sExceptionName, string sEventName, string sControlName, int nErrorLineNo, string sFormName)
        {
            StreamWriter log;
            if (!File.Exists("logfile.txt"))
            {
                log = new StreamWriter("logfile.txt");
            }
            else
            {
                log = File.AppendText("logfile.txt");
            }

            log.WriteLine("Date Time:" + DateTime.Now);
            log.WriteLine("Exception Name:" + sExceptionName);
            log.WriteLine("Event Name:" + sEventName);
            log.WriteLine("Control Name:" + sControlName);
            log.WriteLine("Error Line No:" + nErrorLineNo);
            log.WriteLine("Form Name:" + sFormName);

            log.Close();
        }

        


        private void btnReplicate_Click(object sender, EventArgs e)
        {
            try
            {
                this.timer1.Start();

                string source = Path.Combine(txtSource.Text);
                string destination = Path.Combine(txtDestination.Text);

                Directory.CreateDirectory(destination);

                File.Copy(source, destination, true);

                if (Directory.Exists(source))
                {
                    string[] files = Directory.GetFiles(source);
                    foreach (string s in files)
                    {
                        string name = Path.GetFileName(s);
                        string dest = Path.Combine(destination, name);
                        File.Copy(s, dest, true);
                    }
                }
                else
                {
                    MessageBox.Show("Source path does not exist.");
                }
                File.Move(source, destination);

                Directory.Move(source, destination);

                string backup = @"C:\BMW Folder";

                if (File.Exists(destination))
                    File.Replace(source, destination, backup, false);
            }
            catch (Exception exe)
            {
                LogFile(exe.Message, e.ToString(), ((Control)sender).Name, exe.LineNumber(), this.FindForm().Name);
            }
                

            
        }

        private void btnSource_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.ShowDialog();
            txtSource.Text = folderBrowserDialog1.SelectedPath;
        }

        private void btnDestination_Click(object sender, EventArgs e)
        {
            folderBrowserDialog1.ShowDialog();
            txtDestination.Text = folderBrowserDialog1.SelectedPath;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            this.progressBar1.Increment(1);
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Close();
        }

    }
}
